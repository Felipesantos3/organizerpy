CleanDesk: Auto File Organizer Script
---------------------------------------

How it works:
1. Run the script using Python 3.
2. It will ask for the full folder path you want to organize.
3. It will sort all your files into folders like Images, Documents, etc.

How to run it:
- Make sure you have Python 3 installed
- Open terminal (or command prompt)
- Run: python organize.py

Supported file types:
- Images (.jpg, .png, etc.)
- Documents (.pdf, .txt, etc.)
- Videos, Audio, Code files, and more

Feel free to customize the categories in the script!
